package com.example.eecotraffic;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

public class SpeedPredictFragment extends Fragment {
    private static final String TAG = "SpeedPredict";
    private PageViewModel pageViewModel;

    public SpeedPredictFragment() {
        // Required empty public constructor
    }

    /**
     * @return A new instance of fragment SpeedPredictFragment.
     */
    public static SpeedPredictFragment newInstance() {
        return new SpeedPredictFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pageViewModel = ViewModelProviders.of(this).get(PageViewModel.class);
        pageViewModel.setIndex(TAG);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_speed_predict, container, false);
        return root;
    }
}
