import cv2
import os
import numpy as np 

cap = cv2.VideoCapture('videoplayback.mp4')
car_cascade = cv2.CascadeClassifier('cars.xml')
count=0
number=0
frames_per_second=24

filename = 'video.avi'
my_res='720p'

# Set resolution for the video capture
# Function adapted from https://kirr.co/0l6qmh
def change_res(cap, width, height):
    cap.set(3, width)
    cap.set(4, height)

# Standard Video Dimensions Sizes
STD_DIMENSIONS =  {
    "480p": (640, 480),
    "720p": (1280, 720),
    "1080p": (1920, 1080),
    "4k": (3840, 2160),
}


# grab resolution dimensions and set video capture to it.
def get_dims(cap, res='1080p'):
    width, height = STD_DIMENSIONS["480p"]
    if res in STD_DIMENSIONS:
        width,height = STD_DIMENSIONS[res]
    ## change the current caputre device
    ## to the resulting resolution
    change_res(cap, width, height)
    return width, height

# Video Encoding, might require additional installs
# Types of Codes: http://www.fourcc.org/codecs.php
VIDEO_TYPE = {
    'avi': cv2.VideoWriter_fourcc(*'XVID'),
    #'mp4': cv2.VideoWriter_fourcc(*'H264'),
    'mp4': cv2.VideoWriter_fourcc(*'XVID'),
}

def get_video_type(filename):
    filename, ext = os.path.splitext(filename)
    if ext in VIDEO_TYPE:
      return  VIDEO_TYPE[ext]
    return VIDEO_TYPE['avi']

dims=get_dims(cap,res=my_res)
VIDEO_TYPE_cv2=get_video_type(filename)

out=cv2.VideoWriter(filename,VIDEO_TYPE_cv2,frames_per_second,dims)

while True:
    
    ret, frames = cap.read()
    gray = cv2.cvtColor(frames, cv2.COLOR_BGR2GRAY)
    cars = car_cascade.detectMultiScale(gray, 1.7, 1)
    for (x ,y ,w ,h) in cars:
        cv2.rectangle(frames ,(x ,y) ,( x +w , y +h) ,(0 ,0 ,255) ,2)
        count=count+1
        if count%frames_per_second==0:
            number+=1
    
    font = cv2.FONT_HERSHEY_SIMPLEX
    org = (270, 30) 
    fontScale = 0.5
    color = (255, 0, 0)
    thickness=1
    text="Number of cars"+str(number)
    image = cv2.putText(frames,text, org, font,  
                   fontScale, color, thickness, cv2.LINE_AA)  

    cv2.imshow('vehicle detected', frames)
    out.write(frames)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

print("The total number of cars:",number)
cap.release()
out.release()
cv2.destroyAllWindows()