import java.util.concurrent.TimeUnit;

public class simulation {
    public static Boolean allZeros(int a[]) {
        int i;
        boolean flag = true;
        for (i = 0; i < a.length; ++i)
            if (a[i] != 0)
                flag = false;
        return flag;
    }

    public static void main(String args[]) throws java.lang.InterruptedException {
        Boolean ut, rt;
        int[] upno = new int[6];
        int[] rno = new int[6];
        upno[0] = (int) (Math.random() * 10);
        rno[0] = (int) (Math.random() * 10);
        int emisu = 0, emisr = 0, i = 1, j = 0, k = 0, l = 0;
        ut = false;
        rt = false;
        if (upno[0] > rno[0])
            ut = true;
        else
            rt = true;
        int count = 0;
        while (true) {
            TimeUnit.SECONDS.sleep(1);
            if (ut && emisr >= emisu && count >= 6 || ut && allZeros(upno) || count == 15) {
                ut = false;
                TimeUnit.SECONDS.sleep(2);
                rt = true;
                emisr = 0;
                emisu = 0;
                j = 0;
                k = 0;
                upno[0] = upno[0] + upno[1] + upno[2] + upno[3] + upno[4] + upno[5];
                rno[0] = rno[0] + rno[1] + rno[2] + rno[3] + rno[4] + rno[5];
                for (int m = 1; m < 6; ++m) {
                    upno[m] = 0;
                    rno[m] = 0;
                }
                count = 0;
                i = 1;
                System.out.println("Switching signals");
                continue;
            }
            if (rt && emisu >= emisr && count >= 6 || rt && allZeros(rno) || count == 15) {
                rt = false;
                TimeUnit.SECONDS.sleep(2);
                ut = true;
                emisr = 0;
                emisu = 0;
                j = 0;
                k = 0;
                upno[0] = upno[0] + upno[1] + upno[2] + upno[3] + upno[4] + upno[5];
                rno[0] = rno[0] + rno[1] + rno[2] + rno[3] + rno[4] + rno[5];
                for (int m = 1; m < 6; ++m) {
                    upno[m] = 0;
                    rno[m] = 0;
                }
                count = 0;
                i = 1;
                System.out.println("Switching signals");
                continue;
            }
            if (upno[j] == 0 && j != 3) while (upno[j] == 0 && j < 5) j++;
            if (rno[k] == 0 && k != 3) while (rno[k] == 0 && k < 5) k++;
            if (ut)
                upno[j] -= 1;
            else
                rno[k] -= 1;
            count += 1;
            emisu += upno[0] + upno[1] + upno[2] + upno[3] + upno[4] + upno[5];
            emisr += rno[0] + rno[1] + rno[2] + rno[3] + rno[4] + rno[5];
            if (count % 3 == 0) {
                if (rt) {
                    upno[i] += (int) (Math.random() * 6);
                    rno[i] += (int) (Math.random() * 4);
                }
                if (ut) {
                    rno[i] += (int) (Math.random() * 6);
                    upno[i] += (int) (Math.random() * 4);
                }

                i++;
            }
            System.out.println(emisu + " " + emisr + " " + ut + " " + rt);
            for (l = 0; l < 6; ++l)
                System.out.println(upno[l] + " " + rno[l]);
        }
    }

}
