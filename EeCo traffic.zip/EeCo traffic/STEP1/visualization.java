import java.util.concurrent.TimeUnit;

public class visualization {
    public static void drawEnv(Boolean ut, Boolean rt, int upno[], int rno[], int emisu, int emisr, int time) {
        StdDraw.clear();
        StdDraw.setPenRadius(0.0001);
        StdDraw.line(0.4, 0, 0.4, 0.4);
        StdDraw.line(0.6, 0, 0.6, 0.4);
        StdDraw.line(0.4, 1, 0.4, 0.6);
        StdDraw.line(0.6, 1, 0.6, 0.6);
        StdDraw.line(0, 0.6, 0.4, 0.6);
        StdDraw.line(0, 0.4, 0.4, 0.4);
        StdDraw.line(1, 0.4, 0.6, 0.4);
        StdDraw.line(1, 0.6, 0.6, 0.6);
        StdDraw.setPenColor(StdDraw.LIGHT_GRAY);
        StdDraw.filledRectangle(0.5, 0.5, 0.5, 0.1);
        StdDraw.filledRectangle(0.5, 0.5, 0.1, 0.5);
        if (ut) {
            StdDraw.setPenColor(StdDraw.GREEN);
            StdDraw.filledCircle(0.5, 0.7, 0.05);
        }
        if (!ut) {
            StdDraw.setPenColor(StdDraw.RED);
            StdDraw.filledCircle(0.5, 0.7, 0.05);
        }
        if (rt) {
            StdDraw.setPenColor(StdDraw.GREEN);
            StdDraw.filledCircle(0.7, 0.5, 0.05);
        }
        if (!rt) {
            StdDraw.setPenColor(StdDraw.RED);
            StdDraw.filledCircle(0.7, 0.5, 0.05);
        }
        double count = 0;
        for (int k = 0; k < upno.length; ++k)
            count += upno[k];
        for (int k = 0; k < count; ++k) {
            if (k < 8)
                drawCar(0.45, 0.375 - (k * 0.05));
            else
                drawCar(0.55, 0.375 - ((k - 8) * 0.05));
        }
        count = 0;
        for (int k = 0; k < rno.length; ++k)
            count += rno[k];
        for (int k = 0; k < count; ++k) {
            if (k < 8)
                drawCar(0.375 - (k * 0.05), 0.45);
            else
                drawCar(0.375 - ((k - 8) * 0.05), 0.55);
        }
        StdDraw.setPenColor(StdDraw.BLACK);
        StdDraw.text(0.8, 0.9, "Time elapsed: " + time);
        StdDraw.text(0.8, 0.8, "Emission of up: " + emisu);
        StdDraw.text(0.8, 0.7, "Emission of right: " + emisr);
    }

    public static void drawCar(double x, double y) {
        StdDraw.setPenColor(StdDraw.YELLOW);
        StdDraw.filledSquare(x, y, 0.015);
    }

    public static Boolean allZeros(int a[]) {
        int i;
        boolean flag = true;
        for (i = 0; i < a.length; ++i)
            if (a[i] != 0)
                flag = false;
        return flag;
    }

    public static void main(String args[]) throws java.lang.InterruptedException {
        Boolean ut, rt;
        int[] upno = new int[6];
        int[] rno = new int[6];
        upno[0] = (int) (Math.random() * 10) + 6;
        rno[0] = (int) (Math.random() * 10) + 6;
        int emisu = 0, emisr = 0, i = 1, j = 0, k = 0, l = 0;
        ut = false;
        rt = false;
        if (upno[0] > rno[0])
            ut = true;
        else
            rt = true;
        int count = 0;
        while (true) {
            drawEnv(ut, rt, upno, rno, emisu, emisr, count);
            TimeUnit.SECONDS.sleep(1);
            if (allZeros(upno) && allZeros(rno)) {
                break;
            }
            if (ut == true && emisr >= emisu && count >= 6 || ut == true && allZeros(upno) || count == 15) {
                ut = false;
                drawEnv(ut, rt, upno, rno, emisu, emisr, 0);
                TimeUnit.SECONDS.sleep(2);
                rt = true;
                emisr = 0;
                emisu = 0;
                j = 0;
                k = 0;
                upno[0] = upno[0] + upno[1] + upno[2] + upno[3] + upno[4] + upno[5];
                rno[0] = rno[0] + rno[1] + rno[2] + rno[3] + rno[4] + rno[5];
                for (int m = 1; m < 6; ++m) {
                    upno[m] = 0;
                    rno[m] = 0;
                }
                count = 0;
                i = 1;
                System.out.println("Switching signals");
                continue;
            }
            if (rt == true && emisu >= emisr && count >= 6 || rt == true && allZeros(rno) || count == 15) {
                rt = false;
                drawEnv(ut, rt, upno, rno, emisu, emisr, 0);
                TimeUnit.SECONDS.sleep(2);
                ut = true;
                emisr = 0;
                emisu = 0;
                j = 0;
                k = 0;
                upno[0] = upno[0] + upno[1] + upno[2] + upno[3] + upno[4] + upno[5];
                rno[0] = rno[0] + rno[1] + rno[2] + rno[3] + rno[4] + rno[5];
                for (int m = 1; m < 6; ++m) {
                    upno[m] = 0;
                    rno[m] = 0;
                }
                count = 0;
                i = 1;
                System.out.println("Switching signals");
                continue;
            }

            if (upno[j] == 0 && j != 3) while (upno[j] == 0 && j < 5) j++;
            if (rno[k] == 0 && k != 3) while (rno[k] == 0 && k < 5) k++;
            if (ut)
                upno[j] -= 1;
            else
                rno[k] -= 1;
            count += 1;
            emisu += upno[0] + upno[1] + upno[2] + upno[3] + upno[4] + upno[5];
            emisr += rno[0] + rno[1] + rno[2] + rno[3] + rno[4] + rno[5];
            if (count % 4 == 0) {
                if (rt == true) {
                    upno[i] += (int) (Math.random() * 6) + 1;
                    rno[i] += (int) (Math.random() * 4) + 1;
                }
                if (ut == true) {
                    rno[i] += (int) (Math.random() * 6) + 1;
                    upno[i] += (int) (Math.random() * 4) + 1;
                }

                i++;
            }
            System.out.println(emisu + " " + emisr + " " + ut + " " + rt);
            for (l = 0; l < 6; ++l)
                System.out.println(upno[l] + " " + rno[l]);
        }
    }

}

